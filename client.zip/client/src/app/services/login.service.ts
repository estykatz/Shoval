// import { userInfo } from "os";

// @Injectable({
//     providedIn:'root'
// })




// export class LoginService{
//     private newUser=undefined;
//    LoginChange:subject<boolean>=new subject<boolean>;
//     constructor(){

//     }
//     get IsLogin(){
//         return this.newUser=User;
//     }
//     get newUser(){
//         return this.newUser;
//     }


//     setNewUser(user){
// this.newUser=user;
//         if(user!==undefined){
//             this.loginChange.next(true);
//         }
// else{
//     this.loginChange.next(false)
// }
//        }


// }
