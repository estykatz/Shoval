const attendanceservice = require('../services/attendanceService');



function getListOfStudent() {
    attendanceservice
}
module.exports={
    getListOfStudent
}